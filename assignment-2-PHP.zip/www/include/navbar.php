
<nav class="navbar navbar-expand-md navbar-dark bg-primary fixed-top mb-3">
    <a class="navbar-brand" href="<?php echo URLROOT; ?>/">Group H</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
        <?php if (isset($_SESSION['username'])) : ?>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo URLROOT; ?>/user/logout.php">Logout</a>
            </li>
        <?php else : ?>
            <li class="navbar-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>/user/register.php">Register</a>
            </li>
            <li class="navbar-item">
                <a class="nav-link" href="<?php echo URLROOT; ?>">Login</a>
            </li>
        <?php endif; ?>
        </ul>
    </div>
</nav>